Make the two scripts executable:
chmod +x *.sh

How to use:
1. ./login.sh [username] [password]
2. check the return message contains "successfully logged in", and make sure cookies.txt resides in the same directory with ./upload_*.sh
3. to upload a file in private/public: ./upload_*.sh [file_path]
